================================================================================
Just One Chunk
================================================================================

## Introduction

  Thank you for downloading this map!

  If you upload your own playthrough, I would be grateful if you would link to
  my channel in the video description: https://www.youtube.com/c/Quillbee

  Also, let me know and I'll check it out!

  If you have any problems, you can contact me at: quillbee@danjb.com

## Description

  All 3 dimensions can be reached from a single chunk.
  
  The overworld contains a mini Village, a Ruined Portal, an Abandoned Mine and
  an End Stronghold (with Enderman spawner!); the Nether contains a Fortress
  with a Blaze spawner; and the End contains the End Portal, End Dragon, and a
  single End Crystal!

## Notes

  The animal spawn rate is a little - shall we say - generous. This can be
  fine-tuned from inside the bedrock chamber at the bottom of the map (hint: the
  more chickens in this chamber, the more animals will spawn).
